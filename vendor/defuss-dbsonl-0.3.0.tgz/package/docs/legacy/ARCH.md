# Legacy reference

VERIFIED: These pages preserve the format 1 API and disk specification. They describe the explicit legacy entry, not the current transactional engine. No format-2 guarantees are inferred from these historical contracts.
