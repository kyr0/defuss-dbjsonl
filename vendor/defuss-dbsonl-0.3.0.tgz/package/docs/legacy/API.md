# API reference

Import these APIs from `defuss-dbsonl/legacy`. All asynchronous operations return promises or async iterators. Storage adapters remain caller-owned. `openDbsonl` owns the file it opens; record and maintenance helpers borrow a file and never close it.

## Opening and options

`openDbsonl<T>(adapter, name, options?)` returns a database after complete replay. `name` follows Storage's flat filename rules. Missing files require `create: true`. `readOnly: true` rejects writes; combining it with `create: true` is invalid. Failed open attempts close the acquired handle; a cleanup failure is returned with the original error in an `AggregateError`.

| Option | Default | Meaning |
| --- | ---: | --- |
| `maxRecordBytes` | 16,777,216 | DSON payload bytes, including envelope and binary header, excluding the 16-byte frame header |
| `maxDepth` | 512 | DSON traversal depth |
| `maxReferences` | 1,000,000 | DSON value-table entries |
| `maxKeyLength` | 4,096 | UTF-16 code units; keys must be nonempty strings |
| `maxLiveKeys` | 1,000,000 | Live entries admitted during replay or writes |
| `chunkSize` | 65,536 | Scan I/O bytes, clamped to the handle's `maxReadBytes` |
| `signal` | absent | Structural cancellation signal with `aborted` and optional `reason` |

Codec limits may be zero to reject values exceeding that limit. A custom frame limit must also fit the Storage handle's append admission bound. With defaults, the largest frame is 16,777,232 bytes, below Storage's default 64 MiB single-write limit.

## Database methods

| Method | Result and behavior |
| --- | --- |
| `put(key, value, { signal }?)` | `{ sequence, offset, byteLength }` after append and flush; replaces the logical value |
| `delete(key, { signal }?)` | Same mutation result; appends a tombstone even if the key is absent |
| `get(key, { signal }?)` | `{ found: false }` or `{ found: true, value, sequence }` |
| `has(key)` | Promise of membership, without decoding a value |
| `stats()` | Committed revision, live key count, committed byte length, read-only flag and active reader count |
| `beginRead()` | Stable `ReadSession<T>` with exact `revision` and `size` |
| `scan(options?)` | Async iterator of readonly arrays of `{ key, value, sequence }` |
| `close()` | Closes the owned handle; repeated calls reuse the same promise once close starts |

The `Dbsonl<T>` type is exported as a type; construction is through `openDbsonl`. Decoded values are independent of stored bytes. Mutating a returned value does not update storage. Cross-record references are application keys; object sharing and cycles are preserved only within each value.

`stats()` can report the preceding committed revision while a write is pending. Reads started during a write reject `BUSY`. Mutations started during another mutation or any read session reject `BUSY` before encoding. This API has no implicit wait queue.

## Sessions and batches

A session exposes `get`, synchronous `has`, `scan` and asynchronous `close`. Calling its `scan()` does not transfer ownership; close the session explicitly. Database `scan()` owns its session and closes it on exhaustion, exception or iterator return.

| Scan option | Default | Meaning |
| --- | ---: | --- |
| `batchSize` | 128 | Maximum rows per yielded batch; accepted range is 1 through 4,096 |
| `maxBatchBytes` | 16,777,232 | Maximum sum of encoded frame lengths per batch |
| `signal` | absent | Checked between reads, decoded records and batches |

If a single live frame exceeds `maxBatchBytes`, the scan throws `LIMIT_EXCEEDED`; increase the budget explicitly. A source record is decoded before the batch admission decision, so temporary memory includes that record in addition to the preceding batch. Batch byte accounting is based on persisted sizes, not exact decoded heap sizes.

Scan order is ascending sequence of each key's latest mutation. Updating a key can change its scan position. There is no business-field sorting, pagination cursor, predicate pushdown or estimated count. A future DataView adapter can project a session's record batches while retaining its read lease.

## Physical records

Import these helpers from `defuss-dbsonl/records`:

| Function | Contract |
| --- | --- |
| `appendRecord(file, value, options?)` | Encodes one DSON frame, appends it and returns an offset and length; does not flush |
| `readRecord<T>(file, offsetOrReference, options?)` | Decodes one frame; a supplied reference length must match the stored header |
| `scanRecords<T>(file, options?)` | Yields `{ offset, byteLength, value }` for every physical frame in the selected range |

Record helpers accept codec limits and cancellation. Scans also accept `start`, exclusive `end` and `chunkSize`. End defaults to the size observed at first pull and cannot exceed it. Range boundaries must align with frames; a partial last frame throws `TRUNCATED`.

An offset-only reference is local to its file. Neither references nor generic decoded types establish that a caller chose the right file. Physical helpers do not validate DBSONL envelopes, resolve tombstones, acquire logical snapshots or coordinate multiple helper callers. A concurrent overwrite violates a stable-read assumption even though the scan's end offset is fixed.

## Inspection and repair

`inspectLog(file, options?)` validates framing, checksums, envelope shape, consecutive sequences and resource limits. It returns `status`, `byteLength`, `lastValidOffset`, `recordCount`, `revision`, `liveKeys` and an optional issue. Counts describe the valid prefix when inspection stops early. It builds the same key index as opening a database.

Statuses are `clean`, `incomplete-tail`, `corrupt`, `unsupported` and `limit-exceeded`. `unsupported` identifies an unknown DBSONL envelope version. DSON rejects unsupported wire versions through its decoding errors, which this release conservatively reports as `corrupt`; neither status authorizes repair. Storage I/O errors and cancellation are thrown, not reclassified as byte corruption.

`repairTail(file, { expected, ...options })` accepts only a writable handle and a matching `incomplete-tail` report. It rescans, checks the report's boundary, size and revision, then truncates and flushes. Cancellation is checked before truncation; once truncation begins, repair finishes without cancellation. Reinspection must produce a clean log. File ownership, not the report object, excludes concurrent writers. The report guard is not a cryptographic file-identity token.

## Errors and durability

`DbsonlError` exposes `code`, optional `offset`, optional inspection `report`, and a native `cause` where available. Input shape and range errors use `TypeError` or `RangeError`. Storage failures outside a mutating phase retain Storage's codes.

| Code | Application response |
| --- | --- |
| `BUSY` | Await current work or close read sessions; retry deliberately |
| `CLOSED` | Use another open store or session |
| `READ_ONLY` | Open writable storage only when a mutation is intended |
| `ABORTED` | Stop the caller's operation; do not classify bytes as corrupt |
| `LIMIT_EXCEEDED` | Check the requested resource budget; repair cannot resolve it |
| `TRUNCATED` | Inspect the incomplete physical frame before authorizing repair |
| `CORRUPT`, `INVALID_RECORD`, `UNSUPPORTED_VERSION` | Preserve bytes and investigate; automatic salvage is unsupported |
| `RECOVERY_REQUIRED` | Close the faulted store; inspect and explicitly repair if permitted |
| `REPAIR_REFUSED` | Review the fresh report; nothing was truncated by this call |

The library performs file flushes through the selected adapter. It does not add directory fsync, multi-file atomicity, an exactly-once transaction protocol or cross-process locks. See [format and recovery](FORMAT.md) for persistence semantics.
