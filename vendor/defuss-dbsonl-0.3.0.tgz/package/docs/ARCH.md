# Documentation

VERIFIED: API.md defines public operations, budgets and retry policy. FORMAT.md defines disk structures and publication order. LEGACY.md preserves the v0.1 contract for explicit migration. Root ARCH.md explains the retained format-2 design and platform guarantees. PERFORMANCE.md records v0.3 measurements, reproduction commands and implementation trade-offs. Documentation examples must agree with exported declarations and executable consumer tests.
