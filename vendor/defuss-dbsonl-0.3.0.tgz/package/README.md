# defuss-dbsonl 0.3.0

Transactional DSON record storage for Node.js, Bun and browser workers, built on `defuss-dson` 1.3.0 and `defuss-storage` 0.3.0. TypeScript source, ESM/CommonJS exports and declarations are included.

VERIFIED: v0.2 replaces v0.1's RAM-only key index, read-blocking sessions and single-owner writer admission with a persistent copy-on-write B+tree, immutable snapshots, atomic batches, optimistic transactions, compaction and cross-process coordination. The old format remains available under `defuss-dbsonl/legacy`.

VERIFIED: v0.3 keeps format 2 and all v0.2 operations, with native positional reads, descriptor reuse, overlapped manifest/value reads, bounded scan read-ahead and buffered frame writes. The default native mode remains asynchronous. See [performance evidence and trade-offs](docs/PERFORMANCE.md).

## Install and use

```sh
bun add ./validation/defuss-dbsonl-0.3.0.tgz
# Run from the extracted source ZIP; registry publication is separate.
```

```ts
import { openDbsonl } from 'defuss-dbsonl';
import { createFileBackend } from 'defuss-dbsonl/node';

const backend = await createFileBackend('./data');
const db = await openDbsonl<number>(backend, 'accounts', { create: true });
await db.batch([
  { operation: 'put', key: 'alice', value: 100 },
  { operation: 'put', key: 'bob', value: 50 },
]);

const before = await db.beginRead();
try {
  await db.transaction(async tx => {
    const alice = (await tx.get('alice')).value!;
    const bob = (await tx.get('bob')).value!;
    tx.put('alice', alice - 20);
    tx.put('bob', bob + 20);
  });
  console.log((await before.get('alice')).value); // 100: the snapshot retains its root.
  await db.compact();
} finally {
  await before.close();
  await db.collect();
  await db.close();
}
```

The callback runs once. A concurrent commit produces `CONFLICT`; retry explicitly only when repeating application side effects is safe. `batch()` accepts concurrent writers and serializes publication. `ifRevision` provides compare-and-swap for externally prepared changes.

For memory storage:

```ts
import { createMemoryBackend, openDbsonl } from 'defuss-dbsonl';
const backend = createMemoryBackend();
const db = await openDbsonl(backend, 'example', { create: true });
await db.put('binary', new Uint8Array([1, 2, 3]));
await db.close();
```

For a dedicated browser worker:

```ts
import { createOPFSStorage } from 'defuss-storage/opfs';
import { createBrowserBackend } from 'defuss-dbsonl/browser';
import { openDbsonl } from 'defuss-dbsonl';
const namespace = 'my-app';
const storage = await createOPFSStorage({ name: namespace });
const backend = createBrowserBackend(storage, namespace, navigator.locks);
const db = await openDbsonl(backend, 'documents', { create: true });
await db.put('hello', { bytes: new Uint8Array([42]), time: new Date() });
await db.close();
```

Use the same Web Locks namespace for every adapter accessing the same files. `createDirectoryStorage` can also be wrapped; the application must choose a stable namespace for the directory. With custom Storage admission limits below 64 KiB, supply the accepted write chunk size as the fourth `createBrowserBackend` argument.

## Retained architecture

| v0.1 constraint | v0.2 implementation | Cost |
| --- | --- | --- |
| One writer handle | OS locks or Web Locks coordinate independent clients | Commits still serialize, as required for a single ordered revision |
| Read sessions block writes | Immutable roots and shared generation pins | Old generations remain until readers close |
| RAM map proportional to all keys | Persistent B+tree with bounded LRU page cache | Uncached point reads perform disk I/O |
| Full replay at open | Read two manifest slots and check generation length | Full integrity verification is a separate explicit operation |
| One record per commit | Atomic `batch()` and serializable optimistic `transaction()` | Transaction staging has explicit memory budgets |
| No compaction | Streaming live-value copy and packed index rebuild | Requires temporary disk space; optimistic mode can conflict |
| No process-safe ownership | Whole-file kernel locks for native storage | Native addon; all participating writers must follow the protocol |

VERIFIED: `compact()` permits writes during copying and checks the publication before installation. Use `compact({ mode: 'exclusive' })` to queue writers during copying and guarantee progress under sustained write traffic. Existing snapshots remain readable. `collect()` reclaims unpinned obsolete and abandoned generations; compaction deliberately does not imply collection.

## Guarantees and boundaries

VERIFIED: Published roots provide whole-batch visibility. Values and pages flush before a head slot is written; native factories also sync directory metadata. Two checksummed slots tolerate an interrupted replacement of one slot. Unpublished data tails are reused by a subsequent writer. Published corruption fails validation; there is no automatic destructive repair.

VERIFIED: Native locking uses `@lickle/lock` 0.0.1, whole-file `flock`/`LockFileEx` through its Node-API addon. Linux x64 was tested with Node 24.22.1 and Bun 1.4.3, including process termination. Chromium workers were tested with real OPFS and Web Locks. Memory coordinates only clients sharing the same backend instance.

VERIFIED: This release did not exercise power-cut behavior, network filesystems, macOS, Windows, Firefox or WebKit; their behavior remains unverified. The native factory fails if directory synchronization is unsupported; it does not silently weaken durability. The addon ships Linux x64 glibc, macOS x64/arm64 and Windows x64 binaries. OPFS has no directory-fsync API and reports `durability: 'file'`. Memory reports `'memory'`. No distributed consensus, encryption or hostile-writer protection is implied.

Resource budgets remain necessary. Index caching is independent of key count; cache byte accounting measures encoded page bytes, not JavaScript heap size. Decoded values, active traversal paths, caller-held values, snapshots and the memory adapter's stored bytes are outside that cache budget. See [API](docs/API.md) for defaults and errors. This design addresses the previous architectural constraints; it does not claim a mathematically proven Pareto optimum across every workload.

## Compatibility and migration

VERIFIED: v0.2 and v0.3 share the same on-disk format and lock protocol. The packed-package suite runs both versions concurrently under Node and Bun. Upgrading from v0.2 requires no migration; `/legacy` and `/records` are unchanged.

VERIFIED: v0.2 uses a manifest and generation files; it never interprets or rewrites a v0.1 log as v0.2. Old APIs, record framing and recovery helpers remain in `/legacy` and `/records`. Snapshot creation and stats are asynchronous in v0.2. Scans now yield individual rows ordered by key, rather than batches ordered by latest mutation sequence.

[examples/migrate.ts](examples/migrate.ts) copies a closed-for-writes legacy source into a separate empty destination, checks revision conflicts, compacts and verifies the result. A failed migration leaves a partial destination and preserves the source. Switch consumers only after successful verification. The [legacy reference](docs/LEGACY.md) documents the preserved API.

## Develop and verify

```sh
make setup
make verify
make bench
make vae
make release
```

VERIFIED: `make verify` runs strict type checks, lint, real-storage tests, coverage thresholds and a packed-package suite on Node, Bun and Chromium. The package suite includes mixed Node/Bun processes running both v0.2 and v0.3, crash recovery and concurrent browser workers. `make release` requires the pinned `defuss-vae` 0.9.0 gate, source review and documentation attestation for the current fingerprint. It never publishes or commits. `make` lists every target; `.env.example` documents browser executable overrides.

The ZIP includes the installable tarball, recorded coverage, integration results, benchmark output, VAE gate result and SHA256SUMS. [ARCH.md](ARCH.md) explains the protocol, [FORMAT.md](docs/FORMAT.md) specifies disk layout, and every authored source folder has its own ARCH.md.
