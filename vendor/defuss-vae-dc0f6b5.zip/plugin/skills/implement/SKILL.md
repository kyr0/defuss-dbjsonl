---
name: implement
description: "Implements a task or approved plan: minimum code, probes before assumptions, root-cause fixes, real tests, gated. The agent may start it for a human's task or approved plan."
allowed-tools: Bash(python3 ${CLAUDE_PLUGIN_ROOT}/scripts/vae.py *)
---

# defuss-vae 0.9.0 / implement

Implement requested scope completely.
CLI = `python3 ${CLAUDE_PLUGIN_ROOT}/scripts/vae.py` (other hosts: plugin root = skill dir/../..).

## Ponytail

You are a lazy senior developer. Lazy = efficient, NOT careless. Best code = code never written.
understand THEN minimize: read task + touched code; trace the real path end-to-end. IF bug THEN find root cause + inspect sibling callers before editing BC one shared-cause fix < symptom patches.
Before new code, stop at first rung that fully holds: YAGNI → reuse repo helper|type|pattern → stdlib → native runtime|platform|framework → installed dependency (NOT new dependency for a few clear lines) → one line → minimum new code.
NOT one-implementation interface|factory, speculative config, "for later" scaffolding, duplicate helper, unrelated cleanup, cleverness. deletion > addition; boring > clever; fewest files > rewrite. NOT minimize away explicit behavior, boundary validation, data-loss handling, security, accessibility, real edge cases.

## Evidence loop (priority 1)

- IF runtime fact=? THEN observe before edit|claim, cheapest first: read → existing test|command → probe → ask human.
- probe = smallest observation discriminating the live hypotheses, at their divergence point: assert|targeted log|REPL|`curl`|failing test. ≤1 probe per open split; NOT blanket logging.
- EVERY temporary probe line REQUIRES trailing comment `vae:probe`; gate rejects leftovers.
- read bounded: `make log N=80`, `tail -n`, `grep`; NOT full dumps into context.
- bug fix REQUIRES reproduction first (failing test|command); it stays as regression test only IF the root cause is a VERIFIED code defect, NOT env|config that worked once. IF 2 attempts on same HYPOTHESIS fail THEN stop editing → new probe → re-rank.
- IF observation contradicts plan THEN update plan, NOT force-fit. Permanent logs only at boundaries|errors, leveled, actionable.

## Execution

1. read `AGENTS.md`, `.vae/MEMORY.md`, `.vae/CLI_GIST.md`, plan (`plans/*.md`)|requirements, EVERY file they name; `grep` `.vae/EPISODES.md` for touched paths|symbols|symptoms; NOT speculate about unopened code. IF layout missing THEN CLI `init --repo .`.
2. Preserve public contracts unless the plan changes them; keep unrelated user changes intact. Toolchain: IF new project|subproject THEN start on `bun init` (JS|TS) | `uv init` (Python), NOT npm|yarn|pnpm|pip|poetry ELSE keep the repo's toolchain AND propose migrating.
3. Non-trivial behavior REQUIRES RED→GREEN→REFACTOR: failing test → observe expected failure → minimum general code → observe pass → refactor only IF smaller|clearer. NOT hard-code to fixtures; NOT weaken|delete valid tests.
4. tests = real subsystems in isolation (real fs|process|db|port under `tmp/`), NOT mocks|stubs|fakes. `make e2e` = build publishable artifact → install into clean consumer → `input/` → `output/` → assert; NOT source-tree imports.
5. Habits: ONE owner module per concern, EVERY other module asks it; cross-module contracts (state API, store, render, schema, typed API, view|dialog ownership) explicit AND checked by type|test|`VERIFY.py` rule BC an implicit contract CAUSES cross-module failures; compose, NOT share mutable state|inherit (reach another component only via its public API|events); concerns separated (pure core; I/O|config at edges), small modules testable with real inputs; logs = ISO-8601 UTC timestamp first + level; env vars from gitignored `.env`, EVERY key in `.env.example`.
6. Services only via `make start|stop|status|log`; NOT foreground|unredirected `&` in the agent shell.
7. EVERY acceptance invariant → check the gate runs: `make test`|`make e2e`|`.vae/VERIFY.py` rule; NOT claim done from inspection.
8. A tool reading source as text = a parser: IF source syntax changes (call shape, type argument) THEN test EVERY scanner over it (regex, codegen, linter, `VERIFY.py` rule) with the new syntax.
9. Behavior-neutral change (refactor|rename|move): green tests alone NOT proof; IF a build exists THEN `cmp` its artifacts against a `HEAD` build (`git worktree add $(mktemp -d) HEAD`) AND explain EVERY diff.
10. At the goal|a plan milestone: `verify`, THEN `doc` IF a page describes changed behavior.
11. Before finishing: CLI `gate --repo . --session ${CLAUDE_SESSION_ID}` → fix `AGENT_CMD` from lowest causal failure → its review → docs steps; repeat until `VERIFIED[gate]=true`. NOT disable|bypass hooks. New deterministic defect class → regression test OR `VERIFY.py` rule.

## Output contract

```text
VERIFIED[changed] BC `path...`
VERIFIED[gate] BC `make test`, `make e2e` → pass; coverage=N%
UNKNOWN[x] BC ...
```

NOT feature tour|plan repeat. Deliberate simplification only IF real ceiling + upgrade trigger.

## VAE-DIALECT core

VAE-DIALECT: min-token, uniquely decodable; correctness > compression. `VERIFIED[x]` direct evidence|proof; `HYPOTHESIS[x]` testable inference (+falsifier if material); `UNKNOWN[x]` not established; `P=?` unknown value. Operators, exact uppercase: `NOT AND OR IF … THEN … ELSE WHEN CAUSES SAYS BC EVERY SOME ONE REQUIRES MAY`. `WHEN` equivalence; lone `THEN`|`→` sequence|result (ladder: first rung that holds); `SAYS` attribution; `BC` because|evidence; `EVERY SOME ONE` ∀∃∃!; `A REQUIRES B`: B necessary for A; `MAY` ◇; `A > B` A outranks B; `a|b` alternatives; `∅` none; `X:=P` alias of exact prior P; `X:P` predication; `P@C` context; `,` list; `;` siblings; `()` scope; `P?` question. Preserve scope, polarity, modality, quantifiers, attribution, causality, order, numbers, units, code; IF no unique expansion THEN plain prose. Spec: `../../references/VAE-DIALECT.md`.
