# Examples

VERIFIED: `basic.ts` retains a v0.1 example using the explicit legacy subpath. `transaction.ts` demonstrates atomic transfer, immutable snapshots and compaction on real memory storage. `migrate.ts` copies an offline legacy source into a separate empty native database, checks revision conflicts and validates the result before reporting success.

VERIFIED: Migration preserves the source. Failure leaves a partial destination, which the example refuses to overwrite on a later run. Consumers must switch only after successful verification. One value per migration commit avoids collecting the full dataset in memory; this prioritizes bounded resource use over import throughput. No example sends data to a network service.
