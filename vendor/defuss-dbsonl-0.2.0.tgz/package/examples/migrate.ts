/**
 * VERIFIED: Offline migration to a separate destination. Source bytes are never rewritten.
 * A failed import leaves a partial destination; only switch consumers after verification.
 */
import { createFileStorage } from 'defuss-storage/node';
import { openDbsonl as openLegacy } from 'defuss-dbsonl/legacy';
import { openDbsonl } from 'defuss-dbsonl';
import { createFileBackend } from 'defuss-dbsonl/node';
const [sourceRoot, sourceFile, destinationRoot, destinationName] = process.argv.slice(2);
if (!sourceRoot || !sourceFile || !destinationRoot || !destinationName) throw new Error('Usage: bun examples/migrate.ts SOURCE_ROOT SOURCE_FILE DESTINATION_ROOT DATABASE_NAME');
const source = await openLegacy(await createFileStorage(sourceRoot), sourceFile, { readOnly: true });
try {
  const destination = await openDbsonl(await createFileBackend(destinationRoot), destinationName, { create: true });
  try {
    const initial = await destination.stats();
    if (initial.revision !== 0 || initial.count !== 0) throw new Error('Destination must be a new empty database.');
    let revision = 0;
    for await (const batch of source.scan()) for (const row of batch) {
      // One value per commit bounds migration memory independently of total database size.
      revision = (await destination.put(row.key, row.value, { ifRevision: revision })).revision;
    }
    await destination.compact(); await destination.collect();
    const verified = await destination.verify();
    if (verified.count !== source.stats().liveKeys) throw new Error('Migration count mismatch.');
    console.log(`${new Date().toISOString()} INFO migration_verified records=${verified.count} revision=${verified.revision}`);
  } finally { await destination.close(); }
} finally { await source.close(); }
