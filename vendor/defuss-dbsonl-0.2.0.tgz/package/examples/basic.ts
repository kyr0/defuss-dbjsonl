/** VERIFIED: the example uses only public exports and runs during make e2e. */
import { createMemoryStorage } from 'defuss-storage';
import { openDbsonl } from 'defuss-dbsonl/legacy';

const db = await openDbsonl<{ title: string; updated: Date }>(createMemoryStorage(), 'notes.dsq', { create: true });
try {
  await db.put('first', { title: 'Typed records', updated: new Date('2026-11-13T00:00:00Z') });
  const result = await db.get('first');
  if (!result.found || !(result.value.updated instanceof Date)) throw new Error('Date did not survive storage.');
  for await (const batch of db.scan({ batchSize: 32 })) console.log(batch.map(row => row.key));
} finally { await db.close(); }
