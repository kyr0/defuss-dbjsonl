# Documentation

VERIFIED: API.md defines public operations, budgets and retry policy. FORMAT.md defines disk structures and publication order. LEGACY.md preserves the v0.1 contract for explicit migration. Root ARCH.md explains the reasons for the v0.2 design and platform guarantees. Documentation examples must agree with exported declarations and executable consumer tests.
