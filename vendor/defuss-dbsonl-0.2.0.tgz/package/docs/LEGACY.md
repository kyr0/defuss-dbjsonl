# Preserved v0.1 API

This document describes the legacy subpath only. Use the root README for v0.2.

# defuss-dbsonl

Append-only, typed record storage for embedded databases and graph engines. TypeScript, ESM and CommonJS; memory, native files, OPFS and directory handles through `defuss-storage`.

DBSONL stores DSON frames and resolves replacements and tombstones into a current key-value view. A key index locates individual records without scanning the file. Sequential scans yield bounded batches of live records. Recovery is explicit and never runs as a side effect of opening a file.

## Install

This source distribution builds `defuss-dbsonl@0.1.0`. Install its local tarball after `make release`:

```sh
bun add ./output/defuss-dbsonl-0.1.0.tgz
```

Runtime dependencies are pinned to `defuss-storage@0.3.0` and `defuss-dson@1.3.0`. Node requires 20.19.0 or newer. Browser OPFS runs in a dedicated worker on HTTPS or localhost.

## Store typed values

```ts
import { createMemoryStorage } from 'defuss-storage';
import { openDbsonl } from 'defuss-dbsonl/legacy';

const storage = createMemoryStorage();
const db = await openDbsonl<{ title: string; updated: Date }>(
  storage, 'notes.dsq', { create: true },
);
try {
  await db.put('first', { title: 'Typed records', updated: new Date(0) });
  const result = await db.get('first');
  if (result.found) console.log(result.value.updated.getTime()); // 0
  await db.delete('first');
} finally {
  await db.close();
}
```

`get()` returns `{ found: false }` for an absent key. A stored `undefined` returns `{ found: true, value: undefined, sequence }`. Generic types describe the application's schema; they do not validate decoded values at runtime.

For native persistence, supply `await createFileStorage('./data')` from `defuss-storage/node`. Inside a browser worker, supply `await createOPFSStorage({ name: 'app' })` from `defuss-storage/opfs`. DBSONL never selects or imports a platform adapter.

## Scan current records

```ts
for await (const batch of db.scan({ batchSize: 128, maxBatchBytes: 1024 * 1024 })) {
  for (const { key, value, sequence } of batch) {
    console.log(key, value, sequence);
  }
}
```

This example requires an open database. Results contain each live key once, ordered by its latest mutation sequence. Superseded versions and tombstones are omitted. Stopping a `for await` loop releases its read lease.

A scan holds off writes until it ends. `put()`, `delete()` and database `close()` reject `BUSY` while a read session is active. Await mutations sequentially; concurrent writes also reject `BUSY`. This admission rule prevents an unbounded queue of retained values.

Use `beginRead()` when several lookups and scans must share one revision. Its `revision` and `size` are exact for that session. Always `await session.close()` in a `finally` block. Session closure invalidates paused iterators and waits for outstanding I/O. The database remains caller-owned.

## Inspect and repair

Close the database before opening its file for maintenance:

```ts
import { inspectLog, repairTail } from 'defuss-dbsonl/legacy';

const file = await storage.open('notes.dsq');
try {
  const report = await inspectLog(file);
  if (report.status === 'incomplete-tail') {
    // Application authorization belongs here: this deliberately discards tail bytes.
    const result = await repairTail(file, { expected: report });
    console.log(result.removedBytes);
  }
} finally {
  await file.close();
}
```

`repairTail()` rescans the owned file, requires a matching incomplete-tail report, truncates to the last validated boundary and flushes. Checksum failures, unknown envelope versions, invalid sequences and resource-limit failures refuse repair. A short final header cannot establish why bytes are missing; the application decides whether discarding them is appropriate.

A mutation resolves after append and flush succeed. If either fails after I/O starts, the store rejects further use with `RECOVERY_REQUIRED`. Close it and inspect before reopening. An unacknowledged mutation can survive a restart. Retrying is not an exactly-once operation.

## Entry points

| Import | Exports |
| --- | --- |
| `defuss-dbsonl` | `openDbsonl`, `inspectLog`, `repairTail`, `DbsonlError`, `DEFAULT_LIMITS`, public types |
| `defuss-dbsonl/records` | `appendRecord`, `readRecord`, `scanRecords`, `DbsonlError`, record types |

Record helpers expose physical frames and do not flush automatically. See [API](legacy/API.md), [format and recovery](legacy/FORMAT.md), and [architecture](ARCH.md) for contracts, resource bounds and durability limits.

## Development

Install Bun 1.4.3, Node 24.22.1, Python 3.9 or newer, Git and Make. `mise.toml` pins Node and Bun; `make setup` runs `mise install` when mise is installed.

```sh
make setup
make verify
make bench
make vae
```

`make verify` runs typechecks, oxlint, directory documentation checks, real storage tests, coverage, packed-consumer checks and Chromium worker tests. Browser failures fail verification. `CHROMIUM_EXECUTABLE_PATH` and `CHROMIUM_ARGS` can select an available system browser; both are documented in `.env.example`.

`make vae` uses the bundled, checksum-pinned [defuss-vae](https://github.com/kyr0/defuss-vae) 0.9.0 runtime. It runs verification, then requires review and documentation attestations for the exact source fingerprint. The archive contains upstream VAE unchanged; no global agent configuration is installed. No command commits, pushes or publishes this package.

`make release` requires the VAE gate to pass, then produces the tarball and a complete codebase ZIP with validation reports and SHA-256 checksums. Start with [src/ARCH.md](../src/legacy/ARCH.md) and [tests/ARCH.md](../tests/ARCH.md).

## Scope

Version 0.1 uses one file, one writer and an in-memory live-key index rebuilt on open. It has no compaction, checkpoints, multi-record transactions, secondary indexes or concurrent versioned reads. Deleted and replaced values remain physically present. Queries belong to DataView; schemas and graph relations belong to their model layers.

## License

MIT. Copyright 2026 Aron Homberg.
