# Format and recovery

DBSONL version 1 is a sequence of independent DSON 1.3.0 frames. Empty files are valid. There is no extra file header or newline delimiter. The `.dsq` extension in examples is a convention.

## Logical envelope

A put frame contains exactly these own fields:

```ts
{ dbsonl: 1, sequence: 1, key: 'example', operation: 'put', value: undefined }
```

A delete frame contains exactly these own fields:

```ts
{ dbsonl: 1, sequence: 2, key: 'example', operation: 'delete' }
```

Sequences start at 1, increase by exactly one and remain JavaScript safe integers. Keys are nonempty strings. A put requires its own `value` property even when that value is `undefined`. Unknown fields, operations, missing fields and sequence gaps are invalid. Object property order is not significant to envelope validation.

The key index applies frames in order. A put replaces its key's physical reference; a delete removes that reference. Historical bytes remain unchanged. There is no transaction or commit frame in version 1.

## Physical frame

DSON defines the wire format. Its 16-byte header contains `DSQ` and version 1, a little-endian payload length, a CRC32C of the payload and a CRC32C of the preceding header bytes. The payload is a complete DSON binary value with its own version information. DBSONL calls the published codec instead of reproducing these rules.

An indexed reference stores the absolute frame offset and the total header-plus-payload length. Header inspection bounds allocation before payload decoding. Direct reads can span several Storage reads when a frame exceeds the adapter's maximum read size.

## Recovery decisions

| Observation | Open behavior | Repair behavior |
| --- | --- | --- |
| Empty or entirely valid log | Replay and open | Refuse unnecessary repair |
| Incomplete final header or payload | Reject with inspection report | Permit explicit truncation to last validated boundary |
| Header or payload checksum mismatch | Reject | Refuse |
| Invalid mutation or sequence gap | Reject | Refuse |
| Unsupported envelope version | Reject | Refuse |
| Configured decode/index limit exceeded | Reject with `LIMIT_EXCEEDED` | Refuse |
| Reader unavailable or I/O failure | Throw underlying error | Do not infer a truncation boundary |

Recovery never searches for magic bytes after a damaged frame. An apparent header inside a payload is not evidence of a trustworthy later record. Tail repair discards all bytes after the validated prefix, then flushes and reinspects the result.

## What a successful mutation establishes

A successful mutation has completed encoding, append and the adapter's flush, and is visible through the current in-memory index. Readers cannot overlap its mutating phase.

An unsuccessful mutation after append starts has an uncertain outcome. Its frame may be absent, partial or fully valid. A fully valid frame is replayed even if the original caller never received acknowledgement. Application request IDs and deduplication can provide a higher-level retry policy; this release does not implement it.

A stopped process is not a simulated power failure. Tests verify interrupted byte images, genuine process termination, reopen and explicit repair. They do not establish the power-loss durability of a filesystem, SSD controller or browser. Storage's file-flush guarantee does not cover durable creation of a directory entry or an atomic switch between files.
